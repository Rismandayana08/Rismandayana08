<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index');


$routes->get('public/barang', '\App\Controllers\Api\Barang::index');
$routes->get('public/histori', '\App\Controllers\Api\Histori::index');

$routes->group('api', function($routes) {
    
    $routes->options('login', static function() {
        return \Config\Services::response()->setStatusCode(200);
    });
    
   
    $routes->post('login', '\App\Controllers\Api\Auth::login');

    $routes->resource('barang', ['controller' => '\App\Controllers\Api\Barang', 'filter' => 'apiauth']);
    
    $routes->get('kategori', 'Api\Kategori::index');
    $routes->get('histori', 'Api\Histori::index');
    $routes->get('supplier', 'Api\Supplier::index');
});